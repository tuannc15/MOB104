let express = require('express'),
path = require('path'),
mysql = require('mysql'),
myConnection = require('express-myconnection'),
morgan = require('morgan');
let app = express();
//import router
let customerRouters = require('./routers/customer');
//thiet lap cac thong so cho express
app.set('port',process.env.PORT || 3001);//cong
app.set('views',path.join(__dirname,'views'));//view
app.set('view engine','ejs');//chay duoc file ejs
//ket noi
app.use(morgan('dev'));//che do dev
app.use(myConnection(mysql,{
        host: 'sql.freedb.tech',
		user: 'freedb_hungnq',
		password: 'uCVA!tkpQ47wh%q',
		port: 3306,
		database:'freedb_hungnguyen'
},'single'));//ket noi voi csdl
app.use(express.urlencoded({extended:false}));//cho phep su dung post
//
app.use('/',customerRouters);//su dung router
//
app.use(express.static(path.join(__dirname,'public')));
//khoi dong server
app.listen(app.get('port'),()=>{
    console.log(`Server dang khoi dong o cong ${app.get('port')}`);
});