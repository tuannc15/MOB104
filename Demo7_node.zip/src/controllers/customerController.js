//dinh nghia cac ham
let controller = {};
//1.Ham doc du lieu (select)
controller.list = (req,res)=>{
    req.getConnection((err,conn)=>{
        conn.query('select * from customer',(err,customers)=>{
            if(err)
            {
                res.json(err);
            }
            res.render('customers',{data: customers});
        });
    });
};
//2. Ham luu du lieu (insert)
controller.save = (req,res)=>{
    const data = req.body;
    console.log(req.body);
    req.getConnection((err,conn)=>{
        const query = conn.query('insert into customer set ?',data,(err,customer)=>{
            console.log(customer);
            res.redirect('/');
        });
    });
};
//3. ham edit
controller.edit = (req,res)=>{
    const {id} = req.params;
    req.getConnection((err,conn)=>{
        conn.query("select * from customer where id=?",[id],(err,rows)=>{
            res.render('customers_edit',{data: rows[0]});
        });
    });
};
//4.ham update
controller.update = (req,res)=>{
    const {id} = req.params;
    const newCustomer = req.body;
    req.getConnection((err,conn)=>{
        conn.query('update customer set ? where id=?',[newCustomer,id],(err,rows)=>{
            res.redirect('/');
        });
    });
};
//5.ham delete
controller.delete = (req,res)=>{
    const {id} = req.params;
    req.getConnection((err,conn)=>{
        conn.query('delete from customer where id = ?',[id],(err,rows)=>{
            res.redirect('/');
        });
    });
};
module.exports = controller;