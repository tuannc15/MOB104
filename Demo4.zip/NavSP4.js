import ListProductSP3 from "./ListProductSP3";
import DetailSP4 from "./DetailSP4";
import { createStackNavigator } from "react-navigation-stack";
import { createAppContainer } from "react-navigation";
const RootNavigator = createStackNavigator(
     {
          //Cac file hien thi
          ListProductSP3:
          {
               screen: ListProductSP3,
               navigationOptions:()=>({title:'ListProductSP3'}),
          },
          DetailSP4:
          {
               screen: DetailSP4,
               navigationOptions:()=>({title:'DetailSP4'}),
          },
     },
     {
          //hien thi mac hinh
          initialRouteName: 'ListProductSP3',
     },
);
export default createAppContainer(RootNavigator);