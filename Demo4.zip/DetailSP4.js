import React from "react";
import { ScrollView,Button } from "react-native";
import ProductSP3 from "./ProductSP3";
const DetailSP4=(props)=>{
     //1. Khai bao prop: du lieu, su kien
     const {navigation}=props;//getIntent
     const data=navigation.getParam('data','');//getBundle
     const handlePress=()=>{ //xu ly su kien
          console.log(data);
          props.navigation.navigate('Cart',{data:data});
     }
     //2. giao dien
     return(
          <ScrollView>
               <ProductSP3
                    dataProd={data}/>
               <Button
                    title="Add To Cart"
                    onPress={handlePress}
               />
          </ScrollView>
     );
}
export default DetailSP4;