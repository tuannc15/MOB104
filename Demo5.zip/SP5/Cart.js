import React,{useState} from "react";
import { FlatList,ScrollView,View,Text, Button } from "react-native";
import ProductSP3 from "./ProductSP3";
global.mycart=[];
const Cart=(props)=>{
     //1. khai bao props
     const {navigation}=props;//getIntent
     const data=navigation.getParam('data','');//getBundle
     //2. Khai bao su kien
     const [count, setCount]=useState(1);
     const [list,setList]=useState([]);
     const DanhSachSanPham=()=>
     {
          setList(global.mycart);
          const newList=[{data},...global.mycart];
          setList(newList);
          global.mycart=newList;
          console.log("Gio hang sau khi them: ");
          console.log(global.mycart);
     }
     const renderItems=({index,item})=>
     {
          return(
               <ProductSP3
               dataProd={global.mycart[index].data}
               />
          );
     }
     //3. Return
     return(
          <View>
               <ScrollView>
                    <ProductSP3
                         dataProd={data}
                    />
                    <Button
                         title="+"
                         onPress={()=>setCount(count+1)}
                    />
                    <Button
                         title="-"
                         onPress={()=>setCount(count-1)}
                    />
                    <Text>Nam mua {count} san pham</Text>
                    <Button
                         title="Danh sach san pham"
                         onPress={DanhSachSanPham}
                    />
               </ScrollView>
               <FlatList
                    data={global.mycart}
                    renderItem={renderItems}
                    numColumns={2}
                    removeClippedSubviews
               />
          </View>
     );
}
export default Cart;