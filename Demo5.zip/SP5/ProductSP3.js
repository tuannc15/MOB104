import React from "react";
import { Text,View,Image,StyleSheet,TouchableWithoutFeedback } 
from "react-native";
export default class ProductSP3 extends React.Component{
     constructor()
     {
          super();
          this.props={
               dataProd: {},//nhan du lieu trinh bay
               handlePress: null,
          };
          this.fun_handlePress=this.fun_handlePress.bind(this);
          
     }
     fun_handlePress()
     {
         this.props.handlePress?this.props.handlePress(this.props.dataProd):null;
          console.log("goi ham fun_handlePress:"+this.props.handlePress);
     }
     render()
     {
          return(
               <View style={styles.container}>
                    <TouchableWithoutFeedback onPress={this.fun_handlePress} >
                         <View>
                         <Image source={{uri:this.props.dataProd.search_image}}
                         style={styles.image}/>
                         <Text>{this.props.dataProd.styleid}</Text>
                         <Text>{this.props.dataProd.brands_filter_facet}</Text>
                         <Text>{this.props.dataProd.price}</Text>
                         <Text>{this.props.dataProd.product_additional_info}</Text>
                         </View>
                         
                    </TouchableWithoutFeedback>
               </View>
          );
     }
}
const styles=StyleSheet.create({
     container:{
          flex:1,
     },
     image:{
          width:200,height:200,borderWidth:1,
     },
});