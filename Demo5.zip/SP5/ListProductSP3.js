import React from "react";
import { FlatList } from "react-native";
import ProductSP3 from "./ProductSP3";
export default class ListProductSP3 extends React.Component{
     //1.khai bao state
     constructor()
     {
          super();
          this.state={
               prd: null, //nhan gia tri la 1 object
          };
          this.getProducts=this.getProducts.bind(this);
          this.ketXuatDuLieuItem=this.ketXuatDuLieuItem.bind(this);
          this.handlePress=this.handlePress.bind(this);

     }
     //2.Dinh nghia cac ham: doc du lieu tu server; tao cac item;
     async getProducts()//doc du lieu
     {
          const url='https://hungnttg.github.io/shopgiay.json';
          let response= await fetch(url,{method:'GET'});//doc du lieu
          let responseJSON= await response.json();//chuyen sang json
          //update vao state
          this.setState({
               prd: responseJSON.products,
          });
     }
     handlePress(dataProd)
     {
          this.props.navigation.navigate('DetailSP4',{data:dataProd});
     }
     ketXuatDuLieuItem({item})
     {
          return(
               <ProductSP3
                dataProd={item}
                handlePress={this.handlePress}
                />
          );   
     }
     //3. Goi ham doc du lieu khi chay app
     componentDidMount()
     {
          this.getProducts();
     }
     //4. ket xuat du lieu Flatlist
     render()
     {
          return(
               <FlatList
                    data={this.state.prd}
                    renderItem={this.ketXuatDuLieuItem}
                    numColumns={3}
                    removeClippedSubviews
               />
          );
     }
}