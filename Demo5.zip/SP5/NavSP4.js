import ListProductSP3 from "./ListProductSP3";
import DetailSP4 from "./DetailSP4";
import Cart from "./Cart";
import { createStackNavigator } from "react-navigation-stack";
import { createAppContainer } from "react-navigation";
const RootNav = createStackNavigator(
     {
          //liet ke cac activity
          ListProductSP3:
          {
               screen: ListProductSP3,
               navigationOptions: ()=>({title:'ListProductSP3'}),
          },
          DetailSP4:
          {
               screen: DetailSP4,
               navigationOptions: ()=>({title:'DetailSP4'}),
          },
          Cart:
          {
               screen: Cart,
               navigationOptions: ()=>({title:'Cart'}),
          },
          
     },
     {
          //set main activity
          initialRouteName: 'ListProductSP3',
     },
);
export default createAppContainer(RootNav);