import React from "react";
import { ScrollView,Button } from "react-native";
import Product from "../src/Product";
const DetailSP4=(props)=>{
     //1. Khai bao props nhan du lieu tu listproduct
     const {navigation}=props;//getIntent
     const data=navigation.getParam('data','');//getBundle
     const handlePress=()=>{
          props.navigation.navigate('Cart',{data:data});
     }
     //2. ket xuat du lieu
     return(
          <ScrollView>
               <Product dataProd={data}
               />
               <Button
               title="Add to cart"
               onPress={handlePress}
               />
          </ScrollView>
     );
}
export default DetailSP4;